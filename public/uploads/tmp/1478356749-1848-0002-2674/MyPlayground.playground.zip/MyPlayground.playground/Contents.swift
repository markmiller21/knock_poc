import UIKit
import Foundation


func containsAtSign(string: String) -> Bool {
    return string.characters.contains("@")
}
let input: String! = "kdkd"
print("\(input.filter(containsAtSign))")

"sffjdklfd".characters.contains("a")
